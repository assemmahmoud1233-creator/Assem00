# Epic Fight X Shadow Sword

Mod for Minecraft Forge 1.20.1

## Requirements
- Minecraft 1.20.1
- Forge 47.x
- **Epic Fight** (mandatory - the mod will not load without it)

## How to build
1. Open this project in IntelliJ IDEA
2. Wait for Gradle to download dependencies
3. Run the Gradle task: `build`
4. The finished .jar will be in `build/libs/`

## Item
- Shadow Sword: Very strong netherite-tier sword (high damage)

## Author
Grok
