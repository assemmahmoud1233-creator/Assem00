package com.shadowsword;

import com.shadowsword.item.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(EFShadowSwordMod.MOD_ID)
public class EFShadowSwordMod {
    public static final String MOD_ID = "ef_shadow_sword";

    public EFShadowSwordMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(modEventBus);
    }
}
